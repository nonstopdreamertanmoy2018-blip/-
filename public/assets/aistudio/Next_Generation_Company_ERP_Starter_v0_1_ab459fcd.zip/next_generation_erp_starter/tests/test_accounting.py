from decimal import Decimal
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def get_token():
    # These defaults are for local development only. Set matching env vars before starting tests.
    response = client.post("/auth/token", data={
        "username": "admin",
        "password": "ChangeThis-Immediately-123!"
    })
    assert response.status_code == 200, response.text
    return response.json()["access_token"]

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_balanced_journal_and_reject_unbalanced():
    token = get_token()
    headers = {"Authorization": f"Bearer {token}"}
    cash = client.post("/accounts", headers=headers, json={
        "code": "1000", "name_en": "Cash", "name_bn": "নগদ", "account_type": "asset"
    })
    if cash.status_code == 409:
        cash_id = next(a["id"] for a in client.get("/accounts", headers=headers).json() if a["code"] == "1000")
    else:
        assert cash.status_code == 200, cash.text
        cash_id = cash.json()["id"]

    capital = client.post("/accounts", headers=headers, json={
        "code": "3000", "name_en": "Owner Equity", "name_bn": "মালিকানা মূলধন", "account_type": "equity"
    })
    if capital.status_code == 409:
        capital_id = next(a["id"] for a in client.get("/accounts", headers=headers).json() if a["code"] == "3000")
    else:
        assert capital.status_code == 200, capital.text
        capital_id = capital.json()["id"]

    good = client.post("/journals", headers=headers, json={
        "entry_date": "2026-01-01", "memo": "Opening capital test",
        "lines": [
            {"account_id": cash_id, "debit": "1000.00", "credit": "0.00"},
            {"account_id": capital_id, "debit": "0.00", "credit": "1000.00"}
        ]
    })
    assert good.status_code == 200, good.text
    assert Decimal(good.json()["total_debit"]) == Decimal("1000.00")
    assert Decimal(good.json()["total_credit"]) == Decimal("1000.00")

    bad = client.post("/journals", headers=headers, json={
        "entry_date": "2026-01-02", "memo": "Unbalanced test",
        "lines": [
            {"account_id": cash_id, "debit": "1000.00", "credit": "0.00"},
            {"account_id": capital_id, "debit": "0.00", "credit": "900.00"}
        ]
    })
    assert bad.status_code == 422
