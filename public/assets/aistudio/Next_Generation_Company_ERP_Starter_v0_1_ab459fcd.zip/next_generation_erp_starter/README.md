# Next Generation Company Limited ERP — Starter v0.1

This is a **development starter**, not a finished ERP and not yet suitable for real company data. It includes:
- FastAPI API
- SQLAlchemy database models
- Password hashing with Argon2
- JWT login
- Basic role checks (`admin`, `accountant`, `employee`)
- Accounts and balanced journal entry endpoints
- Basic trial-balance aggregation
- A bilingual sample invoice HTML page with browser print / Save as PDF
- A starter accounting test

## 1. Requirements
- Python 3.11 or newer
- A terminal / command prompt
- For production: PostgreSQL, HTTPS, a managed secrets store, monitoring and tested backups

## 2. Install locally (Windows PowerShell)
```powershell
cd next_generation_erp_starter
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set a unique `JWT_SECRET` and an admin password. The default development password must be changed before use. For this starter, environment variables are read directly by the application; if using a `.env` file, export/load those variables in your shell or use a dotenv loader. Do not commit `.env` to source control.

Example PowerShell variables for a local run:
```powershell
$env:JWT_SECRET = "put-a-long-random-secret-here"
$env:BOOTSTRAP_ADMIN_USERNAME = "admin"
$env:BOOTSTRAP_ADMIN_PASSWORD = "Use-A-Unique-Long-Password-Here"
uvicorn app.main:app --reload
```

Open:
- API documentation: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/health
- Sample printable invoice: sign in in Swagger (`/auth/token`) and then open `/documents/sample-invoice` with the Bearer token in Swagger. Use Print → Save as PDF.

## 3. Run tests
Set the same bootstrap credentials in the test shell before running tests:
```powershell
$env:BOOTSTRAP_ADMIN_USERNAME = "admin"
$env:BOOTSTRAP_ADMIN_PASSWORD = "ChangeThis-Immediately-123!"
pytest -q
```
The included test expects the default development credentials. Do not use these for a real deployment.

## 4. PostgreSQL
Create a PostgreSQL database and dedicated least-privilege database user. Set:
```powershell
$env:DATABASE_URL = "postgresql+psycopg://erp_user:URL_ENCODED_PASSWORD@localhost:5432/nextgen_erp"
```
Use a strong unique password, firewall restrictions and TLS where applicable. Add Alembic migrations before production; do not rely on `create_all()` for ongoing production schema changes.

## 5. Important production gaps
Before real use, add and test:
- Frontend UI, language switcher and accessibility
- Password reset, MFA, login throttling and session/token revocation
- Admin-managed users and permission matrix
- CSRF protection if cookie-based auth is adopted; strict CORS and security headers
- Immutable audit log for sensitive operations
- Journal reversal/approval workflows and fiscal periods
- Correct trial-balance debit/credit presentation by account balance and accounting policy
- Profit & loss, balance sheet, cash flow and reconciliation tests
- Invoice numbering, tax/VAT configuration and local legal review
- PDF rendering, file access controls and document retention rules
- Automated encrypted off-site backups and restoration drills
- Monitoring, error reporting, dependency scanning, penetration testing and load testing
- Deployment pipeline, HTTPS, secrets management and incident response procedures

## 6. Architecture direction
Recommended next modules:
1. Company settings, users and permissions
2. Chart of accounts and journal approvals
3. General ledger, trial balance and financial statements
4. Clients, projects, service tickets, contracts and timesheets
5. Quotations, invoices, payments and receivables
6. HR and payroll
7. Document templates and reporting
8. Cloud deployment, backups and load/security tests

Keep all amounts as decimal/numeric values, never binary floating point. Use database transactions for posting journals. Require independent accountant review before financial statements are used officially.
