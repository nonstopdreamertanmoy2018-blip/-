from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Generator

import jwt
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.responses import HTMLResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pwdlib import PasswordHash
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import (
    create_engine, String, Integer, DateTime, ForeignKey, Numeric, Boolean, select
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session

APP_NAME = os.getenv("APP_NAME", "Next Generation Company Limited ERP")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./erp_dev.db")
JWT_SECRET = os.getenv("JWT_SECRET", "development-only-change-this-secret")
JWT_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "30"))
BOOTSTRAP_ADMIN_USERNAME = os.getenv("BOOTSTRAP_ADMIN_USERNAME", "admin")
BOOTSTRAP_ADMIN_PASSWORD = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "ChangeThis-Immediately-123!")

if JWT_SECRET == "development-only-change-this-secret" and os.getenv("ENVIRONMENT") == "production":
    raise RuntimeError("Set a strong JWT_SECRET before production deployment.")

engine_kwargs = {"pool_pre_ping": True}
if DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}
engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
password_hash = PasswordHash.recommended()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_digest: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default="employee")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

class Account(Base):
    __tablename__ = "accounts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    name_en: Mapped[str] = mapped_column(String(150))
    name_bn: Mapped[str] = mapped_column(String(150), default="")
    account_type: Mapped[str] = mapped_column(String(20))  # asset/liability/equity/revenue/expense
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

class JournalEntry(Base):
    __tablename__ = "journal_entries"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entry_date: Mapped[str] = mapped_column(String(10))  # ISO date YYYY-MM-DD
    memo: Mapped[str] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(20), default="posted")
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    lines: Mapped[list["JournalLine"]] = relationship(back_populates="entry", cascade="all, delete-orphan")

class JournalLine(Base):
    __tablename__ = "journal_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entry_id: Mapped[int] = mapped_column(ForeignKey("journal_entries.id"))
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    debit: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=Decimal("0.00"))
    credit: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=Decimal("0.00"))
    entry: Mapped[JournalEntry] = relationship(back_populates="lines")

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class AccountCreate(BaseModel):
    code: str = Field(min_length=1, max_length=20)
    name_en: str = Field(min_length=1, max_length=150)
    name_bn: str = Field(default="", max_length=150)
    account_type: str = Field(pattern="^(asset|liability|equity|revenue|expense)$")

class AccountOut(AccountCreate):
    id: int
    is_active: bool
    model_config = ConfigDict(from_attributes=True)

class JournalLineInput(BaseModel):
    account_id: int
    debit: Decimal = Field(default=Decimal("0.00"), ge=0, max_digits=14, decimal_places=2)
    credit: Decimal = Field(default=Decimal("0.00"), ge=0, max_digits=14, decimal_places=2)

class JournalCreate(BaseModel):
    entry_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    memo: str = Field(min_length=1, max_length=500)
    lines: list[JournalLineInput] = Field(min_length=2)

class JournalOut(BaseModel):
    id: int
    entry_date: str
    memo: str
    status: str
    total_debit: Decimal
    total_credit: Decimal

class TrialBalanceRow(BaseModel):
    account_code: str
    account_name: str
    debit: Decimal
    credit: Decimal

app = FastAPI(title=APP_NAME, version="0.1.0", description="Starter ERP API. Not production-hardened yet.")

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_access_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user.id),
        "role": user.role,
        "iat": now,
        "exp": now + timedelta(minutes=JWT_EXPIRE_MINUTES),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    unauthorized = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired access token",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        user_id = int(payload["sub"])
    except Exception:
        raise unauthorized
    user = db.get(User, user_id)
    if not user or not user.is_active:
        raise unauthorized
    return user

def require_roles(*roles: str):
    def dependency(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return dependency

def bootstrap() -> None:
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        admin = db.scalar(select(User).where(User.username == BOOTSTRAP_ADMIN_USERNAME))
        if not admin:
            db.add(User(
                username=BOOTSTRAP_ADMIN_USERNAME,
                password_digest=password_hash.hash(BOOTSTRAP_ADMIN_PASSWORD),
                role="admin",
                is_active=True,
            ))
            db.commit()

@app.on_event("startup")
def on_startup() -> None:
    bootstrap()

@app.get("/health")
def health():
    return {"status": "ok", "service": APP_NAME, "version": "0.1.0"}

@app.post("/auth/token", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == form.username))
    if not user or not user.is_active or not password_hash.verify(form.password, user.password_digest):
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    return TokenResponse(access_token=create_access_token(user))

@app.get("/auth/me")
def who_am_i(user: User = Depends(get_current_user)):
    return {"id": user.id, "username": user.username, "role": user.role, "is_active": user.is_active}

@app.post("/accounts", response_model=AccountOut)
def create_account(
    data: AccountCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin", "accountant")),
):
    if db.scalar(select(Account).where(Account.code == data.code)):
        raise HTTPException(status_code=409, detail="Account code already exists")
    account = Account(**data.model_dump())
    db.add(account)
    db.commit()
    db.refresh(account)
    return account

@app.get("/accounts", response_model=list[AccountOut])
def list_accounts(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return list(db.scalars(select(Account).order_by(Account.code)).all())

@app.post("/journals", response_model=JournalOut)
def create_journal(
    data: JournalCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles("admin", "accountant")),
):
    # Each line must be debit OR credit, never both or neither.
    for line in data.lines:
        if (line.debit > 0 and line.credit > 0) or (line.debit == 0 and line.credit == 0):
            raise HTTPException(status_code=422, detail="Each journal line must contain either debit or credit, not both")
        if not db.get(Account, line.account_id):
            raise HTTPException(status_code=422, detail=f"Account {line.account_id} does not exist")
    total_debit = sum((line.debit for line in data.lines), Decimal("0.00"))
    total_credit = sum((line.credit for line in data.lines), Decimal("0.00"))
    if total_debit <= 0 or total_debit != total_credit:
        raise HTTPException(status_code=422, detail="Journal is not balanced: total debit must equal total credit")

    entry = JournalEntry(
        entry_date=data.entry_date,
        memo=data.memo,
        status="posted",
        created_by=user.id,
        lines=[
            JournalLine(account_id=line.account_id, debit=line.debit, credit=line.credit)
            for line in data.lines
        ],
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return JournalOut(
        id=entry.id, entry_date=entry.entry_date, memo=entry.memo, status=entry.status,
        total_debit=total_debit, total_credit=total_credit,
    )

@app.get("/reports/trial-balance", response_model=list[TrialBalanceRow])
def trial_balance(db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "accountant"))):
    accounts = db.scalars(select(Account).order_by(Account.code)).all()
    output = []
    for account in accounts:
        lines = db.scalars(
            select(JournalLine).where(JournalLine.account_id == account.id)
        ).all()
        debit = sum((line.debit for line in lines), Decimal("0.00"))
        credit = sum((line.credit for line in lines), Decimal("0.00"))
        if debit or credit:
            output.append(TrialBalanceRow(
                account_code=account.code, account_name=account.name_en,
                debit=debit, credit=credit,
            ))
    return output

@app.get("/documents/sample-invoice", response_class=HTMLResponse)
def sample_invoice(user: User = Depends(get_current_user)):
    # Demonstration template only; production invoices must be built from validated database records.
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Sample invoice</title>
<style>
body{{font-family:Arial,sans-serif;color:#172033;margin:32px}}
header{{display:flex;justify-content:space-between;border-bottom:2px solid #223b65;padding-bottom:16px}}
h1{{margin:0;color:#223b65}} table{{width:100%;border-collapse:collapse;margin-top:24px}}
th,td{{border:1px solid #ccd3df;padding:10px;text-align:left}} .right{{text-align:right}}
.note{{margin-top:28px;color:#566174}} .print{{padding:10px 16px;margin-bottom:20px}}
@media print{{.print{{display:none}} body{{margin:12mm}}}}
</style></head><body>
<button class="print" onclick="window.print()">Print / Save as PDF</button>
<header><div><h1>Next Generation Company Limited</h1><p>Sample invoice · নমুনা চালান</p></div>
<div><strong>INVOICE / চালান</strong><p>Number: DEMO-0001</p><p>Date: 2026-01-01</p></div></header>
<p>Client / গ্রাহক: Example Client</p>
<table><thead><tr><th>Description / বিবরণ</th><th>Qty</th><th class="right">Unit price (BDT)</th><th class="right">Amount (BDT)</th></tr></thead>
<tbody><tr><td>Software service (demo)</td><td>1</td><td class="right">10,000.00</td><td class="right">10,000.00</td></tr>
<tr><td colspan="3" class="right"><strong>Total / মোট</strong></td><td class="right"><strong>10,000.00</strong></td></tr></tbody></table>
<p class="note">DEMO ONLY — not a tax invoice and not a real transaction. Replace with approved company data and local tax requirements before use.</p>
<p>Prepared by: ____________________ &nbsp;&nbsp; Authorized signature: ____________________</p>
</body></html>"""
    return HTMLResponse(html)

@app.get("/")
def root():
    return {
        "service": APP_NAME,
        "message_en": "ERP API is running",
        "message_bn": "ERP API চালু আছে",
        "docs": "/docs",
        "warning": "Development starter only; complete production security review before real use.",
    }
